"""
LeFo Test Suite.

Unit and integration tests for the Leader-Follower signal prediction framework.

Author: Mohammad Ali Vahedifar (av@ece.au.dk)
Copyright (c) 2025 Mohammad Ali Vahedifar
"""
